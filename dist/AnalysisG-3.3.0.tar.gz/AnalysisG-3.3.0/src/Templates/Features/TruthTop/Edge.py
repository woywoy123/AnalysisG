def res_edge(a, b):
    return a.FromRes * b.FromRes
