def eta(a):
    return a.eta


def energy(a):
    return a.e


def pT(a):
    return a.pt


def phi(a):
    return a.phi


def res_node(a):
    return a.FromRes
