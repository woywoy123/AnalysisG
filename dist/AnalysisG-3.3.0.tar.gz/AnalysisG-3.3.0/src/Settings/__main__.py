if __name__ == "__main__":
    CONFIG_PYAMI()
    CHECK_CUDA()
    POST_INSTALL_PYC()
    AUTH_PYAMI()
